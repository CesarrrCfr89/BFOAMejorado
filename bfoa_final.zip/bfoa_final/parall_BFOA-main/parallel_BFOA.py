from copy import copy
from multiprocessing import Manager, Pool
import time
from bacteria import bacteria
import numpy
import copy
from fastaReader import fastaReader
import random

# -------------------------------------------------------------------------
# NUEVA FUNCIÓN - MUTACIÓN ADAPTATIVA
# -------------------------------------------------------------------------
def adaptive_mutation(bacterium):
    """Aplica una mutación ligera en la estructura de un bacterium"""
    mutated = copy.deepcopy(bacterium)
    
    # Asegurarnos de que los elementos sean listas, no tuplas
    mutated = [list(seq) if isinstance(seq, tuple) else seq for seq in mutated]
    
    seq_idx = random.randint(0, len(mutated) - 1)  # selecciona una secuencia aleatoria
    seq = list(mutated[seq_idx])  # Convertimos a lista aquí
    
    if len(seq) > 1:
        idx1 = random.randint(0, len(seq) - 1)
        idx2 = random.randint(0, len(seq) - 1)
        seq[idx1], seq[idx2] = seq[idx2], seq[idx1]
        
    mutated[seq_idx] = seq  # Asignamos la nueva secuencia mutada
    return mutated



# -------------------------------------------------------------------------
# MAIN
# -------------------------------------------------------------------------

if __name__ == "__main__":
    numeroDeBacterias = 4
    numRandomBacteria = 1
    iteraciones = 3
    tumbo = 2  # número de gaps a insertar 
    nado = 3
    secuencias = list()
    
    secuencias = fastaReader().seqs
    names = fastaReader().names

    # hace todas las secuencias listas de caracteres
    for i in range(len(secuencias)):
        secuencias[i] = list(secuencias[i])

    globalNFE = 0  # número de evaluaciones de la función objetivo

    dAttr = 0.1
    wAttr = 0.002
    hRep = dAttr
    wRep = 0.001

    manager = Manager()
    numSec = len(secuencias)
    print("numSec: ", numSec)
    
    poblacion = manager.list(range(numeroDeBacterias))
    names = manager.list(names)
    NFE = manager.list(range(numeroDeBacterias))

    def poblacionInicial():
        for i in range(numeroDeBacterias):
            bacterium = []
            for j in range(numSec):
                bacterium.append(secuencias[j])
            poblacion[i] = list(bacterium)

    operadorBacterial = bacteria(numeroDeBacterias)
    veryBest = [None, None, None]  # índice, fitness, secuencias

    start_time = time.time()

    print("poblacion inicial ...")
    poblacionInicial()

    for it in range(iteraciones):
        print(f"Iteración {it+1}/{iteraciones}")

        # -----------------------------------------------------------------
        # APLICAMOS MUTACIÓN ADAPTATIVA CADA 2 ITERACIONES
        # -----------------------------------------------------------------
        if it % 2 == 0 and it != 0:
            print("Aplicando mutación adaptativa en bacterias de bajo desempeño...")
            operadorBacterial.creaGranListaPares(poblacion)
            operadorBacterial.evaluaBlosum()
            operadorBacterial.creaTablaFitness()
            fitnesses = operadorBacterial.tablaFitness
            promedio_fitness = sum(fitnesses) / len(fitnesses)
            for i in range(numeroDeBacterias):
                if fitnesses[i] < promedio_fitness:
                    poblacion[i] = adaptive_mutation(poblacion[i])

        print("poblacion inicial creada - Tumbo ...")
        operadorBacterial.tumbo(numSec, poblacion, tumbo)
        print("Tumbo Realizado - Cuadrando ...")
        operadorBacterial.cuadra(numSec, poblacion)
        print("poblacion inicial cuadrada - Creando granLista de Pares...")
        operadorBacterial.creaGranListaPares(poblacion)
        print("granList: creada - Evaluando Blosum Parallel")
        operadorBacterial.evaluaBlosum()
        print("blosum evaluado - creando Tablas Atract Parallel...")

        operadorBacterial.creaTablasAtractRepel(poblacion, dAttr, wAttr, hRep, wRep)
        operadorBacterial.creaTablaInteraction()
        print("tabla Interaction creada - creando tabla Fitness")
        operadorBacterial.creaTablaFitness()
        print("tabla Fitness creada ")
        
        globalNFE += operadorBacterial.getNFE()

        bestIdx, bestFitness = operadorBacterial.obtieneBest(globalNFE)
        if (veryBest[0] is None) or (bestFitness > veryBest[1]):
            veryBest[0] = bestIdx
            veryBest[1] = bestFitness
            veryBest[2] = copy.deepcopy(poblacion[bestIdx])

        operadorBacterial.replaceWorst(poblacion, veryBest[0])
        operadorBacterial.resetListas(numeroDeBacterias)

    print("Very Best: ", veryBest)
    print("--- %s seconds ---" % (time.time() - start_time))
